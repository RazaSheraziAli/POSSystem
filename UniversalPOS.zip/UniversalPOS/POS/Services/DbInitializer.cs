﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using POS.Models;
// Adjust namespaces as necessary
// using PosSystem.Models;
namespace POS.Services
{
    public static class DbInitializer
    {
        private static readonly string[] Roles = new[]
        {
        "Manager", // Full access: Inventory, Reports, User Management
        "Cashier"  // Limited access: Only the main POS terminal/Sales screen
        };
        public static async Task InitializeAsync(IServiceProvider serviceProvider)
        {
            // Get the required services from the dependency injection container
            using var scope = serviceProvider.CreateScope();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            // 1. Ensure Roles exist
            await SeedRolesAsync(roleManager);

            // 2. Create an initial Admin/Manager user
            await SeedManagerUserAsync(userManager);
        }

        private static async Task SeedRolesAsync(RoleManager<IdentityRole> roleManager)
        {
            foreach (var role in Roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    // Create the role if it does not exist
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }
        }
        private static async Task SeedManagerUserAsync(UserManager<ApplicationUser> userManager)
        {
            // Check if the default Manager user already exists
            if (await userManager.FindByEmailAsync("admin@pos.com") == null)
            {
                var user = new ApplicationUser
                {
                    UserName = "admin@pos.com",
                    Email = "admin@pos.com",
                    EmailConfirmed = true,
                    FirstName = "System",
                    LastName = "Manager"
                };

                // Use a secure default password for the initial setup
                var result = await userManager.CreateAsync(user, "Pa$$w0rd1"); // IMPORTANT: Change this password immediately!

                if (result.Succeeded)
                {
                    // Assign the Manager role to the newly created user
                    await userManager.AddToRoleAsync(user, "Manager");
                }
                // If creation fails (e.g., password policy violated), errors will be in 'result.Errors'
            }
        }
    }
}
