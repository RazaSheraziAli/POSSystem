﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace POS.Models
{
    public class Sale
    {
        [Key]
        public int SaleID { get; set; }

        // Foreign Key to the ApplicationUser (Employee) who performed the sale.
        // This is now a string to match the ApplicationUser.Id type.
        public string CashierId { get; set; }

        [ForeignKey("CashierId")]
        // Navigation property now links to the ApplicationUser
        public virtual ApplicationUser Cashier { get; set; }

        public DateTime SaleDate { get; set; } = DateTime.Now;

        [DataType(DataType.Currency)]
        public decimal TotalAmount { get; set; }

        public string PaymentMethod { get; set; } // e.g., "Cash", "Card", "Credit"

        // Navigation property for the items in this sale
        public virtual ICollection<SaleItem> SaleItems { get; set; }=
        new List<SaleItem>();
    }
}
