﻿namespace POS.Models
{
        public class EmployeeSalesSummary
        {
            public string EmployeeName { get; set; }
            public int TransactionsCount { get; set; }
            public decimal TotalSalesValue { get; set; }
        }
    public class PaymentMethodSummary
    {
        public string Method { get; set; } // e.g., "Cash", "Card"
        public decimal TotalValue { get; set; }
    }
    // Master model for the main dashboard view
    public class SalesReportViewModel
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        // Key Metrics
        public decimal GrandTotalRevenue { get; set; } = 0.00m;
        public int TotalTransactions { get; set; } = 0;
        public int TotalItemsSold { get; set; } = 0;

        // Detailed Summaries
        public List<EmployeeSalesSummary> EmployeeSummaries { get; set; }
        public List<PaymentMethodSummary> PaymentSummaries { get; set; }
    }

}
