﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace POS.Models
{
    public class ApplicationUser : IdentityUser
    {
        // The base IdentityUser already provides:
        // - Id (string, used as the PK and FK)
        // - UserName (inherited)
        // - Email (inherited)
        // - PasswordHash, SecurityStamp, etc.
        [Required]
        [StringLength(50)]
        public string?FirstName { get; set; }

        [Required]
        [StringLength(50)]
        public string ?LastName { get; set; }

        // Navigation property for sales handled by this employee
        public virtual ICollection<Sale> Sales { get; set; }

        // NOTE on Role: Identity handles roles via the IdentityRole table
        // and the UserRoles join table. We will use the built-in Identity mechanisms for roles (Manager/Cashier).
    
}
}
