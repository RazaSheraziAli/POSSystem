﻿using POS.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace POS.Models.ViewModels
{
    public class SaleViewModel
    {
        // The list of all active products available for sale
        public IEnumerable<Product> AvailableProducts { get; set; }

        // Represents the current cart items being prepared for sale
        public List<SaleItemViewModel> CartItems { get; set; } = new List<SaleItemViewModel>();

        // The total calculated amount of the sale
        public decimal SaleTotal { get; set; } = 0.00m;
    }

    // A simplified model for items currently in the cart (before being finalized into a SaleItem)
    public class SaleItemViewModel
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal LineTotal => UnitPrice * Quantity;
    }
   
        public class ProcessSaleItemVM
        {
            public int ProductID { get; set; }
            public int Quantity { get; set; }
            public decimal UnitPrice { get; set; }
        }

        public class ProcessSaleViewModel
        {
            public List<ProcessSaleItemVM> Items { get; set; }
            public decimal TotalAmount { get; set; }
            public string PaymentMethod { get; set; }
    }

    
        public class CreateSaleEntryModel
        {
            [Required]
            public List<CreateSaleItemModel> Items { get; set; }

            [Required]
            [Range(0, 999999)]
            public decimal TotalAmount { get; set; }

            [Required]
            public string PaymentMethod { get; set; }
        }

        public class CreateSaleItemModel
        {
            [Required]
            public int ProductID { get; set; }

            [Required]
            [Range(1, 9999)]
            public int Quantity { get; set; }

            [Required]
            [Range(0.01, 999999)]
            public decimal UnitPrice { get; set; }
        }
    }



