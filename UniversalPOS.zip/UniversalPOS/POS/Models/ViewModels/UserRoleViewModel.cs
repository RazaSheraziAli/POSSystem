﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace POS.Models.ViewModels
{
    public class UserRoleViewModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        // Role is a simplified string representation for display
        public string Role { get; set; } = "None";
    }
    public class ManageUserRolesViewModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }

        // List of all possible roles in the system
        public List<IdentityRole> AllRoles { get; set; }

        // List of the roles this specific user currently has
        public List<string> UserRoles { get; set; } = new List<string>();
    }
}
