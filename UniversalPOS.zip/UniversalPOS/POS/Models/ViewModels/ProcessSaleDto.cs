﻿using System.Collections.Generic;
namespace POS.Models.ViewModels
{
        public class ProcessSaleDto
        {
            public List<SaleItemDto> Items { get; set; }
            public decimal TotalAmount { get; set; }
            public string PaymentMethod { get; set; } // "Cash" or "Card"
        }

        public class SaleItemDto
        {
            public int ProductID { get; set; }
            public int Quantity { get; set; }
            public decimal UnitPrice { get; set; }
        }
    
}
