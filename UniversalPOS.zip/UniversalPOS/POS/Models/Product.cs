﻿using System.ComponentModel.DataAnnotations;
namespace POS.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public int StockQuantity { get; set; } // Current inventory level

        public bool IsActive { get; set; } = true;

        // Navigation property for related sale items
        public virtual ICollection<SaleItem> SaleItems { get; set; }
            = new List<SaleItem>();

    }
}
