﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace POS.Models
{
    public class SaleItem
    {
        [Key]
        public int SaleItemID { get; set; }

        // Foreign Key to the parent Sale
        public int SaleID { get; set; }

        [ForeignKey("SaleID")]
        public virtual Sale Sale { get; set; }

        // Foreign Key to the Product sold
        public int ProductID { get; set; }

        [ForeignKey("ProductID")]
        public virtual Product Product { get; set; }

        public int QuantitySold { get; set; }

        // Price is stored here to keep sales history accurate
        [DataType(DataType.Currency)]
        public decimal UnitPriceAtSale { get; set; }

        [DataType(DataType.Currency)]
        public decimal Subtotal { get; set; } = 0;
    }
}
