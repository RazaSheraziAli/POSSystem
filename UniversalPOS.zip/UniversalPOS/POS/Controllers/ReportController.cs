﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POS.Data; // Adjust namespace
using POS.Models;

namespace POS.Controllers
{
    [Authorize(Roles = "Manager")]
    public class ReportController : Controller
    {
        private readonly POSDbContext _context;
        public ReportController(POSDbContext context)
        {
            _context = context;
        }

        // GET: Report/Index
        // Displays the sales dashboard, defaulting to the last 30 days.
        public async Task<IActionResult> Index(DateTime? startDate, DateTime? endDate)
        {
            // [Image of Business Intelligence Dashboard Diagram]

            DateTime reportEndDate = endDate?.Date.AddDays(1).AddSeconds(-1) ?? DateTime.Now;
            DateTime reportStartDate = startDate?.Date ?? DateTime.Now.AddDays(-30);

            // 1. Fetch all relevant sales within the date range, including navigation properties
            var sales = await _context.Sales
                .Include(s => s.Cashier) // Employee details
                .Include(s => s.SaleItems) // Items sold in the transaction
                .Where(s => s.SaleDate >= reportStartDate && s.SaleDate <= reportEndDate)
                .ToListAsync();

            // 2. Calculate Key Metrics
            decimal grandTotalRevenue = sales.Sum(s => s.TotalAmount);
            int totalTransactions = sales.Count;
            int totalItemsSold = sales.SelectMany(s => s.SaleItems).Sum(si => si.QuantitySold);

            // 3. Aggregate Sales by Employee
            var employeeSummaries = sales
                .GroupBy(s => s.Cashier)
                .Select(g => new EmployeeSalesSummary
                {
                    EmployeeName = $"{g.Key.FirstName} {g.Key.LastName}",
                    TransactionsCount = g.Count(),
                    TotalSalesValue = g.Sum(s => s.TotalAmount)
                })
                .OrderByDescending(s => s.TotalSalesValue)
                .ToList();

            // 4. Aggregate Sales by Payment Method
            var paymentSummaries = sales
                .GroupBy(s => s.PaymentMethod)
                .Select(g => new PaymentMethodSummary
                {
                    Method = g.Key,
                    TotalValue = g.Sum(s => s.TotalAmount)
                })
                .OrderByDescending(s => s.TotalValue)
                .ToList();

            // 5. Build the ViewModel
            var viewModel = new SalesReportViewModel
            {
                StartDate = reportStartDate,
                EndDate = reportEndDate,
                GrandTotalRevenue = grandTotalRevenue,
                TotalTransactions = totalTransactions,
                TotalItemsSold = totalItemsSold,
                EmployeeSummaries = employeeSummaries,
                PaymentSummaries = paymentSummaries
            };

            return View(viewModel);
        }
    }
}
