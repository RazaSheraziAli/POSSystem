﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POS.Data;
using POS.Models;
using POS.Models.ViewModels;
using System.Security.Claims;
using System.Text.Json;

namespace POS.Controllers
{
    [Authorize(Roles = "Manager,Cashier")]
    public class SalesController : Controller
    {
        private readonly POSDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public SalesController(POSDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var activeProducts = await _context.Products
                .Where(p => p.IsActive)
                .OrderBy(p => p.Name)
                .ToListAsync();

            var viewModel = new SaleViewModel
            {
                AvailableProducts = activeProducts,
                CartItems = new List<SaleItemViewModel>()
            };

            return View(viewModel);
        }


        // ------------------------------------------------------
        // ADD TO CART
        // ------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddToCart(int ProdID, int Quantity)
        {
            try
            {
                var product = await _context.Products.FindAsync(ProdID);
                if (product == null)
                    return Json(new { success = false, message = "Product not found." });

                var cart = HttpContext.Session.GetObject<List<SaleItem>>("Cart")
                           ?? new List<SaleItem>();

                var existing = cart.FirstOrDefault(c => c.ProductID == ProdID);

                if (existing == null)
                {
                    cart.Add(new SaleItem
                    {
                        ProductID = product.ProductID,
                        UnitPriceAtSale = product.Price,
                        QuantitySold = Quantity
                    });
                }
                else
                {
                    existing.QuantitySold += Quantity;
                }

                HttpContext.Session.SetObject("Cart", cart);

                return Json(new { success = true, cart });
            }
            catch
            {
                return Json(new { success = false, message = "Failed to add item to cart." });
            }
        }



        // ------------------------------------------------------
        // PROCESS SALE
        // ------------------------------------------------------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessSale([FromBody] ProcessSaleViewModel model)
        {
            if (model == null || model.Items == null || !model.Items.Any())
                return Json(new { success = false, message = "No sale data received." });

            var cashierId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var sale = new Sale
            {
                CashierId = cashierId,
                SaleDate = DateTime.Now,
                PaymentMethod = model.PaymentMethod,
                TotalAmount = model.TotalAmount,
                SaleItems = new List<SaleItem>()
            };

            foreach (var item in model.Items)
            {
                var product = await _context.Products.FindAsync(item.ProductID);

                if (product == null)
                    return Json(new { success = false, message = $"Product not found: {item.ProductID}" });

                if (product.StockQuantity < item.Quantity)
                    return Json(new { success = false, message = $"Insufficient stock for {product.Name}" });

                product.StockQuantity -= item.Quantity;

                sale.SaleItems.Add(new SaleItem
                {
                    ProductID = product.ProductID,
                    QuantitySold = item.Quantity,
                    UnitPriceAtSale = item.UnitPrice
                });
            }

            _context.Sales.Add(sale);
            await _context.SaveChangesAsync();

            // Clear Cart Session
            HttpContext.Session.Remove("Cart");

            return Json(new { success = true, saleId = sale.SaleID });
        }



        // ------------------------------------------------------
        // RECEIPT
        // ------------------------------------------------------
        public async Task<IActionResult> Receipt(int id)
        {
            var sale = await _context.Sales
                .Include(s => s.SaleItems)
                .ThenInclude(si => si.Product)
                .Include(s => s.Cashier)
                .FirstOrDefaultAsync(s => s.SaleID == id);

            if (sale == null)
                return NotFound();

            return View(sale);
        }
    }


    // ------------------------------------------------------
    // SESSION EXTENSIONS
    // ------------------------------------------------------
    public static class SessionExtensions
    {
        public static void SetObject<T>(this ISession session, string key, T value)
        {
            session.SetString(key, JsonSerializer.Serialize(value));
        }

        public static T GetObject<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default : JsonSerializer.Deserialize<T>(value);
        }
    }
}
