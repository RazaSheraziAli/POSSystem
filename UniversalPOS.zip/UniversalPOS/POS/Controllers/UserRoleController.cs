﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POS.Data; // Adjust namespace
using POS.Models; // Adjust namespace
using POS.Models.ViewModels; // Adjust namespace

namespace POS.Controllers
{

    [Authorize(Roles = "Manager")]
    public class UserRoleController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UserRoleController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }
        public async Task<IActionResult> Index()
        {
            var users = await _userManager.Users.ToListAsync();
            var userRolesList = new List<UserRoleViewModel>();

            // [Image of User Role Management Diagram]

            foreach (var user in users)
            {
                var roles = await _userManager.GetRolesAsync(user);
                userRolesList.Add(new UserRoleViewModel
                {
                    UserId = user.Id,
                    UserName = user.UserName,
                    Email = user.Email,
                    Role = roles.FirstOrDefault() ?? "Unassigned" // Display the first role found
                });
            }

            return View(userRolesList);
        }
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null) return NotFound();

            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            var allRoles = await _roleManager.Roles.ToListAsync();
            var userRoles = await _userManager.GetRolesAsync(user);

            var viewModel = new ManageUserRolesViewModel
            {
                UserId = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                AllRoles = allRoles,
                UserRoles = userRoles.ToList()
            };

            return View(viewModel);
        }

        // POST: UserRole/Edit/5 (Logic to update roles)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string userId, List<string> selectedRoles)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null) return NotFound();

            // 1. Get current roles
            var existingRoles = await _userManager.GetRolesAsync(user);

            // 2. Remove roles the user no longer has
            var rolesToRemove = existingRoles.Except(selectedRoles ?? new List<string>()).ToList();
            if (rolesToRemove.Any())
            {
                await _userManager.RemoveFromRolesAsync(user, rolesToRemove);
            }

            // 3. Add roles the user should have now
            var rolesToAdd = (selectedRoles ?? new List<string>()).Except(existingRoles).ToList();
            if (rolesToAdd.Any())
            {
                await _userManager.AddToRolesAsync(user, rolesToAdd);
            }

            // Redirect back to the user list
            return RedirectToAction(nameof(Index));
        }
    }
}
