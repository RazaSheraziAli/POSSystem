﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using POS.Models;

namespace POS.Data
{
    public class POSDbContext : IdentityDbContext<ApplicationUser>
    {
        public POSDbContext(DbContextOptions<POSDbContext> options)
            : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<SaleItem> SaleItems { get; set; }

        // Override OnModelCreating to configure the relationships and constraints
        protected override void OnModelCreating(ModelBuilder builder)
        {
            // Must call the base method to ensure Identity tables are created correctly
            base.OnModelCreating(builder);

            // --- Custom Fluent API Configuration ---

            // 1. Sale to ApplicationUser (Cashier) relationship
            builder.Entity<Sale>()
                .HasOne(s => s.Cashier)
                .WithMany(u => u.Sales)
                .HasForeignKey(s => s.CashierId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent accidental deletion of a user if they have recorded sales

            // 2. Sale to SaleItem relationship (One Sale has many SaleItems)
            builder.Entity<SaleItem>()
                .HasOne(si => si.Sale)
                .WithMany(s => s.SaleItems)
                .HasForeignKey(si => si.SaleID);

            // 3. Product to SaleItem relationship (One Product can be in many SaleItems)
            builder.Entity<SaleItem>()
                .HasOne(si => si.Product)
                .WithMany(p => p.SaleItems)
                .HasForeignKey(si => si.ProductID)
                .OnDelete(DeleteBehavior.Restrict); // Keep data integrity

            // Ensure decimal properties use the correct precision and scale for currency
            builder.Entity<Product>()
                .Property(p => p.Price)
                .HasColumnType("decimal(18, 2)");

            builder.Entity<SaleItem>()
                .Property(si => si.UnitPriceAtSale)
                .HasColumnType("decimal(18, 2)");

            builder.Entity<SaleItem>()
                .Property(si => si.Subtotal)
                .HasColumnType("decimal(18, 2)");

            builder.Entity<Sale>()
                .Property(s => s.TotalAmount)
                .HasColumnType("decimal(18, 2)");
        }
    }
}
